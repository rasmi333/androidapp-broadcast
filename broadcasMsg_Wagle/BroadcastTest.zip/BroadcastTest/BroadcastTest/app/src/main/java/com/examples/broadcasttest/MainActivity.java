package com.examples.broadcasttest;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {
    Button myButton1;
    Button myButton2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        myButton1 = (Button) findViewById(R.id.btn_msg1);
        myButton1.setOnClickListener(this);
        myButton2 = (Button) findViewById(R.id.btn_msg2);
        myButton2.setOnClickListener(this);


    }
    @Override
    public void onClick (View v) {
        // Broadcast an intent
        if(v==myButton1){
            Intent intent = new Intent();
            intent.setAction("com.examples.broadcasttest.MSG1");
            sendBroadcast(intent);
        }
        else if(v==myButton2){
            Intent intent = new Intent();
            intent.setAction("com.examples.broadcasttest.MSG2");
            sendBroadcast(intent);
        }
    }
    }

